def guessGender():
    return

def generateUUID():
    return

def generateMockData():
    return