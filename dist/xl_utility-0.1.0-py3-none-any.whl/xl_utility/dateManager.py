def getFullDate():
    return

def getDateDetail():
    return

def getShortDate():
    return