def separateNames():
    return 

def separateAddresses():
    return 

def capitalizeFirstLetter():
    return

def capitalizeAll():
    return
    